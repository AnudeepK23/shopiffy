# shopiffy


shoppify is an online shopping portal for all your daily needs

its a simple interface, fast, and easy one step payment

provides
### spring security API
### Maps API

and other web dependencies



